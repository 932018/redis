﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using redis.Data;
using System.Text.Json.Serialization;

namespace redis.Controllers
{
    [ApiController]
    [Route("[action]")]
    public class HomeController : Controller
    {
        private readonly IDistributedCache _distributedCache;
        private readonly Context _context;
        public HomeController(IDistributedCache distributedCache , Context context) 
        {
            _distributedCache = distributedCache;
            _context = context;
        }
        [HttpGet]
        public string Get() 
        {
            var value = _distributedCache.GetString("key");
            if(value != null)
            {
                return value;
            }
            else
            {
                var option = new DistributedCacheEntryOptions();
                option.SetAbsoluteExpiration(DateTimeOffset.Now.AddSeconds(20));
                _distributedCache.SetString("key", "found",option);
                return "not found";
            }
        }


        [HttpPost]
        public async Task<IActionResult> Add([FromBody] Student student)
        {
            await _context.Students.AddAsync(student);
            await _context.SaveChangesAsync();
            return Ok(student);
        }
        [HttpGet]
        public async Task<IActionResult> GetStudent()
        {


            var studentkey=await _distributedCache.GetStringAsync("keyst");


            if(studentkey != null)
            {
                var st= JsonConvert.DeserializeObject<List<Student>>(studentkey);
                return Ok(st);
            }
            else
            {
                var st = await _context.Students.ToListAsync();
                var option = new DistributedCacheEntryOptions();
                option.SetAbsoluteExpiration(DateTimeOffset.Now.AddSeconds(20));
                await _distributedCache.SetStringAsync("keyst", JsonConvert.SerializeObject(st),option);
                return Ok(st);
            }

            
        }











    }
}
