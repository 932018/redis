﻿using Microsoft.EntityFrameworkCore;

namespace redis.Data
{
    public class Context : DbContext
    {
        public Context(DbContextOptions<Context> options) : base(options) { }
        public DbSet<Student> Students { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder);
        //    modelBuilder.Entity<Student>()
        //   .HasKey(ms => new { ms.id });
        //}
    }
}
