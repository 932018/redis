﻿using System.ComponentModel.DataAnnotations;

namespace redis.Data
{
    public class Student
    {

        public int Id { set; get; }
        public string Name { set; get; }
        public string Address { set; get; }
    }
}
